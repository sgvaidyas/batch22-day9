﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Sample
    {
        public int x;
        public Sample(int a)
        {
            x = a;
            Console.WriteLine("X = " + x);
        }
        public virtual void message()
        {
            Console.WriteLine("SAMPLE CLASS");
        }
    }
    class Sample2:Sample
    {
        public int y;
        public Sample2(int a,int b):base(a)
        {
            y = b;
            Console.WriteLine("hey i m here & y="+y);
        }
        public  override void message()
        {
            Console.WriteLine("SAMPLE 2");
        }
    }
    class Sample3:Sample2
    {
        public int z;
        public Sample3(int a,int b,int c):base(a,b)
        {
            z = c;
            Console.WriteLine("Z= "+z);
        }
        public sealed override void message()
        {
            Console.WriteLine("SAMPLE 3");
        }
    }
    class Sample4:Sample3
    {
        readonly int myvar = 77;//valid initialize
        public Sample4(int a,int b,int c):base(a,b,c)
        {
            myvar++;//valid to change
            Console.WriteLine("myvar = "+myvar);
        }
        public void message()
        {
            // error myvar++;
            Console.WriteLine("myvar = " + myvar);
            Console.WriteLine("SAMPLE 4");
        }
    }
    class Sealedexample
    {
        static void Main(string[] args)
        {
            Sample ob = new Sample4(33, 5, 7);
            ob.message();

        }
    }
}
