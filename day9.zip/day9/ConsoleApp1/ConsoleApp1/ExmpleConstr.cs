﻿using System;

namespace ConsoleApp1
{
    class A
    {
        public int x, y;
        public A(int a,int b)
        {
            x = a;
            y = b;
        }
    }
    class B:A
    {
        public int m, n;
        public B(int a,int b,int c,int d):base(c,d)
        {            
            m = a; 
            n = b;
        }
        public void display()
        {
            Console.WriteLine("x={0} y={1} m={2} n{3}" , x,y,m,n);
        }
    }
    class ExmpleConstr
    {
        static void Main(string[] args)
        {
            B ob = new B(11, 22, 1, 2);
            ob.display();
        }
    }
}
