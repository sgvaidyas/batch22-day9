﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Addition
    {
        public void sum(int a,int b)
        {
            Console.WriteLine("(int,int)SUM = "+(a+b));
        }
        public void sum(int a, int b,int c)
        {
            Console.WriteLine("(int,int,int )SUM = " + (a + b+c));
        }
        public void sum(float a,float b)
        {
            Console.WriteLine("(float,float)SUM = " + (a+b));
        }

    }
    class Overloadingexample
    {
        static void Main(string[] args)
        {
            Addition ob = new Addition();

            ob.sum(33, 5);
            ob.sum(5, 7, 8);
            ob.sum(8.8f, 9.6f);
            ob.sum(33f, 55f);
            ob.sum(3.3f, 5);
        }
    }
}
