﻿using System;

namespace ConsoleApp1
{
    abstract class Assessment
    {
        public int m1, m2;
        public Assessment()
        {
            Console.WriteLine("Enter M1 and M2 = ");
            m1 = int.Parse(Console.ReadLine());
            m2 = int.Parse(Console.ReadLine());
        }
        public static  void fun1()
        {
            Console.WriteLine("hi i am static");
        }
        
        public abstract void caltotal();
    }

    abstract class ImplementAssess1:Assessment
    {
        public ImplementAssess1()
        {
            Console.WriteLine("i am in ImplementAssess1");
        }

    }
    class ImplementAssess2: ImplementAssess1
    {
        public int total;
        public override void caltotal()
        {
            total = m1 + m2;
            Console.WriteLine("total = " +total);
        }
    }

    class Abstractsample
    {
        static void Main(string[] args)
        {
            Assessment ob = new ImplementAssess2();
            ob.caltotal();
            Assessment.fun1();
        }
    }
}
