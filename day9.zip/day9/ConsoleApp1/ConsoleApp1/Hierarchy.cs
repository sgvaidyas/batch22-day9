﻿using System;

namespace ConsoleApp1
{
    class Square:Shape
    {
        public int area, peri;
        public void calculate()
        {
            getlen();
            area = len * len;
            peri = 4 * len;

        }
        public void display()
        {
            Console.WriteLine("LENGTH = "+len);
            Console.WriteLine("AREA = " + area);
            Console.WriteLine("PERIMETER = " + peri);

        }
    }
    class Circle:Shape
    {
        public float area, circumference;
        public void calculate()
        {
            getradius();
            area = 3.142f * rad * rad;
            circumference = 2 * 3.142f * rad;

        }
        public void display()
        {
            Console.WriteLine("RADIUS = " + rad);
            Console.WriteLine("AREA = " + area);
            Console.WriteLine("CIRCUMFERENCE = " + circumference);

        }
    }
    class Hierarchy
    {
        static void Main(string[] args)
        {
            Circle ob = new Circle();
            ob.calculate();
            ob.display();

            Square ob1 = new Square();
            ob1.calculate();
            ob1.display();


        }
    }
}
