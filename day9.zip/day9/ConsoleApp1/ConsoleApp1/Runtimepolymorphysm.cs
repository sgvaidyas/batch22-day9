﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class MusicPlayer
    {
        public virtual void play()
        {
            Console.WriteLine("Song plays");
        }
        public virtual void stop()
        {
            Console.WriteLine("Song stopped playing");
        }
    }

    class VLC:MusicPlayer
    {
        public override void play()
        {
            Console.WriteLine("VLC--->Song plays");
        }
        public override void stop()
        {
            Console.WriteLine("VLC--->Song stopped playing");
        }
    }

    class Mediaplayer : MusicPlayer
    {
        public  void play()
        {
            Console.WriteLine("Mediaplayer--->Song plays");
        }
        public  void stop()
        {
            Console.WriteLine("Mediaplayer--->Song stopped playing");
        }
    }
    class Runtimepolymorphysm
    {
        static void Main(string[] args)
        {
            MusicPlayer ob = new VLC();
            ob.play();
            ob.stop();
            MusicPlayer ob1 = new Mediaplayer();
            ob1.play();
            ob1.stop();
        }
    }
}
