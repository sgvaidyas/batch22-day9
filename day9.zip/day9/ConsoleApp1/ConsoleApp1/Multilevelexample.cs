﻿using System;

namespace ConsoleApp1
{
    class Student
    {
        public int roll, classnum;
        public string name;

        public Student()
        {
            Console.WriteLine("ENTER ROLL , CLASSNUM & NAME");
            roll = int.Parse(Console.ReadLine());
            classnum = int.Parse(Console.ReadLine());
            name = Console.ReadLine();
        }
        public Student(int r,int c,string n)
        {
            roll = r;
            classnum = c;
            name = n;
        }

        public  void display()
        {
            Console.WriteLine("ROLL           "+roll);
            Console.WriteLine("NAME           " + name);
            Console.WriteLine("CLASSNUM       " + classnum);
        }

    }

    class  MarksDetails:Student
    {
        public int noofsub,tot;
        public int[] marks;

        public MarksDetails()
        {
            Console.WriteLine("Enter the num of subjects");
            noofsub = int.Parse(Console.ReadLine());
            marks = new int[noofsub];
            Console.WriteLine("Enter the marks");
            for (int i = 0; i < noofsub; i++)
                marks[i] = int.Parse(Console.ReadLine());
            tot = 0;
        }
        public void calculate()
        {
            for (int i = 0; i < noofsub; i++)
                tot += marks[i];

        }
        public void display()
        {
            base.display();
            Console.WriteLine("NO OF SUBJECTS   " + noofsub);
            for (int i= 0;i< noofsub;i++)
            {
                Console.WriteLine("MARKS{0}:          {1} ",i+1,marks[i]);
            }
            Console.WriteLine("TOTAL          " + tot);
            Console.WriteLine();
            
        }
    }


    class Reportcard:MarksDetails
    {
        public string grade;
        int avg;

        public void calculate()
        {
            base.calculate();
            avg = tot / noofsub;
            if (avg >= 60 && avg <= 100)
                grade = "First";
            else if (avg >= 35 && avg <= 59)
                grade = "Second";
            else
                grade = "FAIL";
        }
        public void display()
        {
            base.display();
            Console.WriteLine("AVG            "+avg);
            Console.WriteLine("GRADE         "+grade);
        }
    }

    class Multilevelexample
    {
        static void Main(string[] args)
        {
            Reportcard ob = new Reportcard();
            ob.calculate();
            ob.display();
        }
    }
}
